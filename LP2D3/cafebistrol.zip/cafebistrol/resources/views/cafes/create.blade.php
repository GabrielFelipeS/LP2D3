<x-layout title="Novo Cafe">
    <form action="" method="post">
        <label for="name">Nome: </label>
        <input type="text" id="name" name="name">
    </form>
</x-layout>