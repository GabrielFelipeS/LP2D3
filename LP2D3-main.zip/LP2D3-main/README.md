# LP2D3

Disciplina de linguagem de programação 2 do Instituto Federal de Educação, Ciência e Tecnologia de São Paulo IFSP
