# LP2D3 - Projetos

Sugestão de site para escolha do template https://bootstrapmade.com/

Existem várias categorias como:
- Negócios
- Educação
- Saúde
- Restaurante
- Portfolio
- etc

Preencham a planilha com os temas escolhidos e os nomes dos integrantes:

https://docs.google.com/spreadsheets/d/1rjrDY--G3B4SLdJ7jPaEuBiAXgoBuY9tF43DHabJUvI/edit?usp=sharing